import os
import sys
import subprocess
import threading
import shutil
import uuid
import zipfile
try:
    import requests
except ImportError as e:
    subprocess.run([sys.executable, "-m", "pip", "install", "requests"])
    import requests

os.makedirs("sdlibs", exist_ok=True)

def extract_zip(zip_path, dest_folder):
    """Extract a .zip file to a destination folder"""
    try:
        # Ensure the destination folder exists
        os.makedirs(dest_folder, exist_ok=True)

        # Open the .zip file
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            # Extract all files to the destination folder
            zip_ref.extractall(dest_folder)
            print(f"Extracted {zip_path} to {dest_folder}")
    except Exception as e:
        print(f"Error extracting {zip_path}: {e}")

def download_file(url, dest_path):
    """Download a file from a URL and save it to a destination path"""
    try:
        # Send a GET request to the URL
        response = requests.get(url)
        
        # Check if the request was successful
        if response.status_code == 200:
            # Write the content to the destination file
            with open(dest_path, 'wb') as file:
                file.write(response.content)
            print(f"Downloaded file from {url} to {dest_path}")
        else:
            print(f"Failed to download file from {url}. HTTP Status code: {response.status_code}")
    except Exception as e:
        print(f"Error downloading file from {url}: {e}")

def install_module(url):
    temppath = os.path.join("tmp", str(uuid.uuid4()))
    os.makedirs(temppath, exist_ok=True)
    os.makedirs(os.path.join(temppath, "zipextract"))
    download_file(url, os.path.join(temppath, "library.zip"))
    extract_zip(os.path.join(temppath, "library.zip"), os.path.join(temppath, "zipextract"))
    file = open(os.path.join(temppath, "zipextract", "libname.txt"), mode="r")
    shutil.copytree(os.path.join(temppath, "zipextract"), os.path.join("sdlibs", file.read()))
    file.close()


# Function to import the library and return the class
def import_lib(name):
    # Build the path to the library folder and script file
    libfolder_path = os.path.abspath(os.path.join("sdlibs", name))
    libscriptfile_path = os.path.abspath(os.path.join(libfolder_path, name + ".py"))
    
    # Check if the library folder and script exist
    if os.path.exists(libscriptfile_path):
        # Create an event to communicate the result back
        result_event = threading.Event()
        result = [None]  # Using a list to store the result (can be used for mutation in threads)
        
        # Start a new thread to handle the library import
        thread = threading.Thread(target=execute_script, args=(libfolder_path, libscriptfile_path, result_event, result))
        thread.start()
        
        # Wait for the thread to finish and return the result (the class)
        result_event.wait()
        
        # Return the class from the library
        return result[0]
    else:
        print(f"Library '{name}' not found at {libscriptfile_path}.")
        return None

# Function to execute the script and return the class
def execute_script(libfolder_path, libscriptfile_path, result_event, result):
    # Create a new context for the current thread and change the directory for this thread only
    original_directory = os.getcwd()  # Save the current directory
    
    try:
        # Change directory just for this thread's execution
        os.chdir(libfolder_path)
        
        # Open the script file and read its content
        with open(os.path.abspath(libscriptfile_path), 'r') as libscriptfile:
            libscript = libscriptfile.read()
        
        # Execute the script content in the current thread's context
        exec(libscript, globals())  # 'globals()' to access the global context of this thread
        library_class = globals().get(os.path.basename(libfolder_path))()
        
        # If the class is found, store it in the result list
        if library_class:
            result[0] = library_class
        else:
            result[0] = None
        
        print(f"Library '{libfolder_path}' imported successfully in thread.")
    
    except Exception as e:
        print(f"Error while importing library: {e}")
        result[0] = None
    
    finally:
        # Revert to the original directory after script execution
        os.chdir(original_directory)
        
        # Signal that the thread is done
        result_event.set()

class SDLibraryNotFoundError(Exception):
    """Custom exception for my specific error."""
    def __init__(self, message="The Module Specified Could Not Be Found"):
        self.message = message
        super().__init__(self.message)
