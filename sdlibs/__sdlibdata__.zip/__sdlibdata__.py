import os

def __sdlibdata__(sdlibdata={}):
    return sdlibdata