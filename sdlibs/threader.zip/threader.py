import threading

class threader:
    def __init__(self):
        self.Thread = Thread

class Thread:
    def __init__(self, group=None, target=None, args=(), kwargs=None, daemon=None):
        self.thread = threading.Thread(group=group, target=target, args=args, kwargs=kwargs, daemon=daemon)

    def start(self):
        self.thread.start()

    def join(self):
        self.thread.join()

    def is_alive(self):
        return self.thread.is_alive()

    def get_thread(self):
        return self.thread